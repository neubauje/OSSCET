<!DOCTYPE html>
<html lang="en">
<head>
<title>Grades</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
<div class="container text-center">
<h1>My grades</h1>
</div>
<div>
    This is where students will view a list of all grades previously earned, and currently in progress. 
    Ideally, they will be able to expand each class to see the individual assignments that were graded and contributed to the overall grade. 
    At the bottom of the page will be the student's cumulative GPA.
</div>
</body>
</html>