<!DOCTYPE html>
<html lang="en">
<head>
<title>Grades</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
<div class="container text-center">
<h1>My grades</h1>
</div>
<div>
    This is where teachers will view, edit, and add the grades for the students in their currently-active classes. 
    Each class offering can be expanded to show a list of assignments, which in turn can be expanded to show each student's grade for that assignment.
    Each class offering and assignment will also show a statistical analysis of the grades for all students in the class, allowing teachers to analyze weak points and adjust as needed.
</div>
</body>
</html>